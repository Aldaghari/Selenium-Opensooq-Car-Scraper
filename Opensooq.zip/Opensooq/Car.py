class Car:
    def __init__(self, car_dict: dict[str, str]) -> None:
        self.car_dict = car_dict
